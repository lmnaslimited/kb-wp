<?php 
  $thumbsize = isset($thumbsize) ? $thumbsize : 'medium';
?>

<div class="post-grid v3">
    <article class="post">   
        <figure class="entry-thumb <?php echo  (!has_post_thumbnail() ? 'no-thumb' : ''); ?>">
            <a href="<?php the_permalink(); ?>"  class="entry-image tbay-image-loaded">
                <?php
                    if ( defined('PUCA_VISUALCOMPOSER_ACTIVED') && PUCA_VISUALCOMPOSER_ACTIVED ) {
                        $thumbnail_id = get_post_thumbnail_id(get_the_ID());
                        echo puca_tbay_get_attachment_image_loaded($thumbnail_id, $thumbsize );
                    } else {
                        the_post_thumbnail();
                    }
                ?>
            </a>
        </figure>
        <div class="entry-content"> 
           <div class="entry">
				<div class="meta-info">
					<span class="entry-date"><?php echo puca_time_link(); ?></span>
				</div>
				
                 <div class="entry-meta">
                    <?php
                        if (get_the_title()) {
                        ?>
                            <h4 class="entry-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h4>
                        <?php
                    }
                    ?>
                     
                </div>

                <?php puca_custom_post_category(); ?>

			</div>
        </div>
        <div class="readmore"><a href="<?php the_permalink(); ?>" title="<?php esc_html_e( 'Read More', 'puca' ); ?>"><?php esc_html_e( 'Read More', 'puca' ); ?></a></div>
    </article>
    
</div>
