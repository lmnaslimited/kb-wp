<?php 

$_id = puca_tbay_random_key(); 

?>
<div id="search-form-horizontal-<?php echo esc_attr($_id); ?>" class="search-horizontal">
	<button type="button" class="btn-search-totop">
	  <i class="icon-magnifier"></i>
	</button>
</div>