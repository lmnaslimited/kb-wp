<?php if(is_active_sidebar('topbar-welcome')) : ?>
	<?php dynamic_sidebar('topbar-welcome'); ?>
<?php endif;?>